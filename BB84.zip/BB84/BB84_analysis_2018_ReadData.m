clc;
close all;
clear all;


%%% LOAD DATA FROM FILE %%%%%%%%%%%%%%%%%%%
delta = 81E-12;
PathName = 'C:\JeroWork\Teaching\MyLabs\PHASGQ03_BB84Lab\Experiment\2017\GroupD\';
FileName = 'countdata.txt';
fid = fopen(char(strcat(PathName,FileName)),'r');
format = ['%f',' , ','%f'];
raw = textscan(fid,format,'headerLines',0,'commentStyle',{'TRACE', ':'});

%%% PROCESS DATA %%%%%%%%%%%%%%%%%%%
alltimes = raw{1};
allchannels = raw{2};
